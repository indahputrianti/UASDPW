<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_user extends CI_Model 
{

	public function get_data()
	{
		return $this->db->get('pengguna')->result_array();
	}
}