<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_transaksi extends CI_Model 
{

	public function get_data()
	{
		return $this->db->get('transaksi')->result_array();
	}
}