<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_login extends CI_Model 
{
	public function cek_login($where)
    {
        return $this->db->get_where('pengguna',$where);
	}
}