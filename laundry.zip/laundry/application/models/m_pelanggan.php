<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_pelanggan extends CI_Model 
{

	public function get_data()
	{
        return $this->db->get('pelanggan')->result_array();
	}
}