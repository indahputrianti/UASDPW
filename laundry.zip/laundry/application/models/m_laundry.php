<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_laundry extends CI_Model 
{

	public function get_data()
	{
        return $this->db->get('laundry')->result_array();
	}
}