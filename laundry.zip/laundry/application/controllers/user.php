<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller 
{

	public function index()
	{
        $this->load->view('templates/header');
		$this->load->view('templates/sidebar');
		$this->load->view('templates/topbar');
		$this->load->view('user/home');
		$this->load->view('templates/footer');
	}

	public function pengguna()
	{
		$this->load->model('m_user');
		$data['pengguna']= $this->m_user->get_data();
		$this->load->view('templates/header');
		$this->load->view('templates/sidebar');
		$this->load->view('templates/topbar');
		$this->load->view('user/pengguna', $data);
		$this->load->view('templates/footer');
	}

	public function tambah_pengguna()
	{
		$id_pengguna =$this->input->post('id_pengguna');
		$nama =$this->input->post('nama');
		$username =$this->input->post('username');
		$passwword =$this->input->post('password');

		$data = array(
			'id_pengguna' => $id_pengguna,
			'nama' => $nama,
			'username' => $username,
			'password' => $password,
		);

		$this->m_user->input_data($data, 'pengguna');
		redirect('index.php/user/pengguna', $data);
	}

	public function pelanggan()
	{
		$this->load->model('m_pelanggan');
		$data['pelanggan']= $this->m_pelanggan->get_data();
		$this->load->view('templates/header');
		$this->load->view('templates/sidebar');
		$this->load->view('templates/topbar');
		$this->load->view('user/pelanggan', $data);
		$this->load->view('templates/footer');
	}

	public function tambah_pelanggan()
	{
		$id_pengguna =$this->input->post('id_pelanggan');
		$nama =$this->input->post('nama');
		$username =$this->input->post('alamat');
		$passwword =$this->input->post('telp');

		$data = array(
			'id_pelanggan' => $id_pelanggan,
			'nama' => $nama,
			'alamat' => $alamat,
			'telp' => $telp,
		);

		$this->m_user->input_data($data, 'pelanggan');
		redirect('index.php/user/pelanggan', $data);
	}

	public function laundry()
	{
		$this->load->model('m_laundry');
		$data['laundry']= $this->m_laundry->get_data();
		$this->load->view('templates/header');
		$this->load->view('templates/sidebar');
		$this->load->view('templates/topbar');
		$this->load->view('user/laundry', $data);
		$this->load->view('templates/footer');
	}

	public function tambah_laundry()
	{
		$no_laundry =$this->input->post('no_laundry');
		$id_pelanggan =$this->input->post('id_pelanggan');
		$tgl_terima =$this->input->post('tgl_terima');
		$tgl_selesai =$this->input->post('tgl_selesai');
		$jumlah =$this->input->post('jumlah');
		$catatan =$this->input->post('catatan');
		$status =$this->input->post('status');
		$id_pengguna=$this->input->post('id_pengguna');

		$data = array(
			'no_laundry' => $no_laundry,
			'id_pelanggan' => $id_pelanggan,
			'tgl_terima' => $tgl_terima,
			'tgl_selesai' => $tgl_selesai,
			'jumlah' => $jumlah,
			'catatan' => $catatan,
			'status' => $status,
			'id_pengguna' => $id_pengguna,
		);

		$this->m_user->input_data($data, 'laundry');
		redirect('index.php/user/laundry', $data);
	}

	public function transaksi()
	{
		$this->load->model('m_transaksi');
		$data['transaksi']= $this->m_transaksi->get_data();
		$this->load->view('templates/header');
		$this->load->view('templates/sidebar');
		$this->load->view('templates/topbar');
		$this->load->view('user/transaksi', $data);
		$this->load->view('templates/footer');
	}

	public function tambah_transaksi()
	{
		$no_transaksi =$this->input->post('no_transaksi');
		$tgl_transaksi =$this->input->post('tgl_transaksi');
		$jenis_transaksi =$this->input->post('jenis_transaksi');
		$catatan =$this->input->post('catatan');
		$id_pengguna =$this->input->post('id_pengguna');
		$masuk =$this->input->post('masuk');
		$keluar =$this->input->post('keluar');

		$data = array(
			'no_transaksi' => $no_transaksi,
			'tgl_transaksi' => $tgl_transaksi,
			'jenis_transaksi' => $jenis_transaksi,
			'catatan' => $catatan,
			'id_pengguna' => $id_pengguna,
			'masuk' => $masuk,
			'keluar' => $keluar,
		);

		$this->m_user->input_data($data, 'transaksi');
		redirect('index.php/user/transaksi', $data);
	}
}