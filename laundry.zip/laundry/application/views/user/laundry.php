   
        <!-- Begin Page Content -->
        <div class="container-fluid">

          <!-- Page Heading -->
          <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Laundry</h1>
          </div>

           <!-- Content Row -->
           <div class="row">

           <!-- Content Column -->
           <div class="col-lg-12 mb-4">

           <!-- Approach -->
           <div class="card shadow mb-4">
                <div class="card-header py-3">
                  <h6 class="m-0 font-weight-bold text-primary">Tabel Laundry</h6>
                </div>
                <div class="card-body">

                <button class="btn btn-primary" data-toggle="modal" data-target="#exampleModal"><i class="fa fa-plus"></i>Tambah Data</button>
                <table class="table">
                  <tr>
                    <th>No Laundry</th>
                    <th>Id Pelanggan</th>
                    <th>Tgl Terima</th>
                    <th>Tgl Selesai</th>
                    <th>Jumlah</th>
                    <th>Catatan</th>
                    <th>Status</th>
                    <th>Id Pengguna</th>
                    <th colspan="2">Aksi</th>
                  </tr>                  

                  <?php foreach ($laundry as $ldy) : ?>
                    <tr>
                      <td><?php echo $ldy['no_laundry']; ?></td>
                      <td><?php echo $ldy['id_pelanggan']; ?></td>
                      <td><?php echo $ldy['tgl_terima']; ?></td>
                      <td><?php echo $ldy['tgl_selesai']; ?></td>
                      <td><?php echo $ldy['jumlah']; ?></td>
                      <td><?php echo $ldy['catatan']; ?></td>
                      <td><?php echo $ldy['status']; ?></td>
                      <td><?php echo $ldy['id_pengguna']; ?></td>
                      <td><div class="btn btn-danger btn-sm"><i class="fa fa-trash"></i></div></td>
                      <td><div class="btn btn-primary btn-sm"><i class="fa fa-edit"></i></div></td>
                    </tr>
                  <?php endforeach; ?>
                </table>
                 
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- /.container-fluid -->

        <!-- Modal -->
        <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Form Input Data Laundry</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>
              <div class="modal-body">
                <form method="post" action="<?php echo base_url().'index.php/user/laundry'; ?>">

                <div class="form-group">
                <label>No Laundry</label>
                <input type="text" name="id_pengguna" class="form-control">
                </div>

                <div class="form-group">
                <label>Id Pelanggan</label>
                <input type="text" name="id_pengguna" class="form-control">
                </div>

                <div class="form-group">
                <label>Tgl Terima</label>
                <input type="text" name="nama" class="form-control">
                </div>

                <div class="form-group">
                <label>Tgl Selesai</label>
                <input type="text" name="username" class="form-control">
                </div>

                <div class="form-group">
                <label>Jumlah</label>
                <input type="text" name="password" class="form-control">
                </div>

                <div class="form-group">
                <label>Catatan</label>
                <input type="text" name="id_pengguna" class="form-control">
                </div>

                <div class="form-group">
                <label>Status</label>
                <input type="text" name="id_pengguna" class="form-control">
                </div>

                <div class="form-group">
                <label>Id Pengguna</label>
                <input type="text" name="id_pengguna" class="form-control">
                </div>

                <button type="reset" class="btn btn-danger" data-dismiss="modal">Reset</button>
                <button type="submit" class="btn btn-primary">Simpan</button>
              
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- End of Main Content -->
      