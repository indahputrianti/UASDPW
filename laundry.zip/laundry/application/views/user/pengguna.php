   
        <!-- Begin Page Content -->
        <div class="container-fluid">

          <!-- Page Heading -->
          <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Pengguna</h1>
          </div>

           <!-- Content Row -->
           <div class="row">

           <!-- Content Column -->
           <div class="col-lg-12 mb-4">

           <!-- Approach -->
           <div class="card shadow mb-4">
                <div class="card-header py-3">
                  <h6 class="m-0 font-weight-bold text-primary">Tabel Pengguna</h6>
                </div>
                <div class="card-body">
                  
                <button class="btn btn-primary" data-toggle="modal" data-target="#exampleModal"><i class="fa fa-plus"></i>Tambah Data</button>
                <table class="table">
                    <tr>
                      <th>Id Pengguna</th>
                      <th>Nama</th>
                      <th>Username</th>
                      <th>Password</th>
                      <th colspan="2">Aksi</th>
                    </tr>

                    <?php foreach ($pengguna as $pgn) : ?>
                      <tr>
                        <td><?php echo $pgn['id_pengguna']; ?></td>
                        <td><?php echo $pgn['nama']; ?></td>
                        <td><?php echo $pgn['username']; ?></td>
                        <td><?php echo $pgn['password']; ?></td>
                        <td><div class="btn btn-danger btn-sm"><i class="fa fa-trash"></i></div></td>
                        <td><div class="btn btn-primary btn-sm"><i class="fa fa-edit"></i></div></td>
                      </tr>
                    <?php endforeach; ?>
                  </table>
                  
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- /.container-fluid -->

        <!-- Modal -->
        <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Form Input Data Pengguna</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>
              <div class="modal-body">
                <form method="post" action="<?php echo base_url().'index.php/user/tambah_pengguna'; ?>">

                <div class="form-group">
                <label>Id Pengguna</label>
                <input type="text" name="id_pengguna" class="form-control">
                </div>

                <div class="form-group">
                <label>Nama</label>
                <input type="text" name="nama" class="form-control">
                </div>

                <div class="form-group">
                <label>Username</label>
                <input type="text" name="username" class="form-control">
                </div>

                <div class="form-group">
                <label>Password</label>
                <input type="text" name="password" class="form-control">
                </div>

                <button type="reset" class="btn btn-danger" data-dismiss="modal">Reset</button>
                <button type="submit" class="btn btn-primary">Simpan</button>
              
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- End of Main Content -->
      