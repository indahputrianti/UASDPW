   
        <!-- Begin Page Content -->
        <div class="container-fluid">

          <!-- Page Heading -->
          <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">HOME</h1>
          </div>

           <!-- Content Row -->
           <div class="row">

           <!-- Content Column -->
           <div class="col-lg-12 mb-4">

           <!-- Approach -->
           <div class="card shadow mb-4">
                <div class="card-header py-3">
                  <h6 class="m-0 font-weight-bold text-primary">Tentang</h6>
                </div>
                <div class="card-body">
                  <p>Laundry merupakan jasa yang menyediakan proses pencucian pakaian biasa menggunakan air dan deterjen serta ditambahkan juga pewangi dan pelembut pakaian. Namun jasa laundry kami tidak hanya menyediakan jasa khusus pencucian pakaian saja, tetapi juga menyediakan jasa pencucian sprei, Boneka, Selimut, gorden, dan lain sebagainya.  Selain itu laundry kami juga menggunakan layanan laundry kiloan, karena lebih murah dan cepat daripada laundry satuan.</p>
                  <p class="mb-0">Adapun proses langkah-langkah cara kerja loundry kiloan, yaitu : 
                  <ol type="1">
                    <li>Penerimaan pakaian</li>
                    <li>proses pencucian</li>
                    <li>proses pengeringan</li>
                    <li>Proses penyeterikaan</li>
                    <li>Proses pengepakan</li>
                    <li>proses penaruhan ke-rak</li>
                  </ol>
                  </p>
                  <p class="mb-0">Berikut merupakan daftar harga laundry kami, yaitu : 
                  <ul>
                    <li>Pakaian = 4K/kilo</li>
                    <li>Boneka = 10K/kilo</li>
                    <li>Sprei = 7K/kilo</li>
                    <li>Selimut = 8K/kilo</li>
                    <li>Gorden = 7K/kilo</li>
                    <li>sepatu = 5K/1 Pasang</li>
                  </ul>
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- /.container-fluid -->
      </div>
      <!-- End of Main Content -->
      